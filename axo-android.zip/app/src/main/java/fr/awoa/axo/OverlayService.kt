package fr.awoa.axo

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.ViewGroup
import android.view.WindowManager
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.TextView

class OverlayService : Service() {

    companion object {
        @Volatile
        var running = false
    }

    private var wm: WindowManager? = null
    private var frame: FrameLayout? = null
    private var web: WebView? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        running = true
        startAsForeground()
        addOverlay()
    }

    private fun startAsForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("axo", "Axo", NotificationManager.IMPORTANCE_LOW)
        )
        val pi = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(this, "axo")
            .setContentTitle("Axo est là")
            .setContentText("Touche pour ouvrir Axo")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentIntent(pi)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1, n)
        }
    }

    private fun circle(color: Int): GradientDrawable {
        val g = GradientDrawable()
        g.shape = GradientDrawable.OVAL
        g.setColor(color)
        return g
    }

    @SuppressLint("ClickableViewAccessibility", "SetJavaScriptEnabled")
    private fun addOverlay() {
        val manager = getSystemService(WINDOW_SERVICE) as WindowManager
        wm = manager
        val d = resources.displayMetrics.density

        val container = FrameLayout(this)

        val w = WebView(this)
        w.setBackgroundColor(Color.TRANSPARENT)
        w.settings.javaScriptEnabled = true
        w.settings.domStorageEnabled = true
        w.settings.mediaPlaybackRequiresUserGesture = false
        w.webViewClient = WebViewClient()
        w.loadUrl(Config.URL + "?overlay=1")
        container.addView(
            w,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        )
        web = w

        val size = (36 * d).toInt()

        val handle = TextView(this)
        handle.text = "✥"
        handle.textSize = 16f
        handle.gravity = Gravity.CENTER
        handle.setTextColor(Color.parseColor("#3B2A4A"))
        handle.background = circle(Color.parseColor("#CCFFFFFF"))
        container.addView(
            handle,
            FrameLayout.LayoutParams(size, size, Gravity.TOP or Gravity.START)
        )

        val close = TextView(this)
        close.text = "✕"
        close.textSize = 16f
        close.gravity = Gravity.CENTER
        close.setTextColor(Color.parseColor("#3B2A4A"))
        close.background = circle(Color.parseColor("#CCFFFFFF"))
        container.addView(
            close,
            FrameLayout.LayoutParams(size, size, Gravity.TOP or Gravity.END)
        )

        val lp = WindowManager.LayoutParams(
            (230 * d).toInt(),
            (300 * d).toInt(),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = (30 * d).toInt()
        lp.y = (250 * d).toInt()

        var startX = 0f
        var startY = 0f
        var origX = 0
        var origY = 0
        handle.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = e.rawX
                    startY = e.rawY
                    origX = lp.x
                    origY = lp.y
                }
                MotionEvent.ACTION_MOVE -> {
                    lp.x = origX + (e.rawX - startX).toInt()
                    lp.y = origY + (e.rawY - startY).toInt()
                    manager.updateViewLayout(container, lp)
                }
            }
            true
        }
        close.setOnClickListener { stopSelf() }

        manager.addView(container, lp)
        frame = container
    }

    override fun onDestroy() {
        running = false
        try {
            frame?.let { wm?.removeView(it) }
        } catch (e: Exception) {
        }
        web?.destroy()
        frame = null
        web = null
        super.onDestroy()
    }
}
