package fr.awoa.axo

object Config {
    const val URL = "https://comfy-kulfi-5d119a.netlify.app/"
}
